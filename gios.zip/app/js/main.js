$(window).on("load" , function () {



})



